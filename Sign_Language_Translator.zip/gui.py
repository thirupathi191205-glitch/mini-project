"""gui.py
Simple Tkinter GUI that shows camera preview, predicted label and speaks the label.
Uses OpenCV for camera feed and pyttsx3 or gTTS for speech.
"""
import tkinter as tk
from tkinter import ttk
import threading
import cv2
from PIL import Image, ImageTk
import time
import os
from utils import logger, LABEL_MAP
import numpy as np
from tensorflow.keras.models import load_model
import pyttsx3

MODEL_PATH = os.path.join(os.getcwd(),'models','gesture_model.keras')

class App:
    def __init__(self, root):
        self.root = root
        self.root.title('Sign Language Translator')
        self.cap = cv2.VideoCapture(0)
        self.model = load_model(MODEL_PATH)
        self.label_var = tk.StringVar(value='---')
        self._running = True
        self.engine = pyttsx3.init()
        # UI
        self.video_label = ttk.Label(root)
        self.video_label.grid(row=0,column=0,columnspan=2)
        ttk.Label(root, text='Prediction:').grid(row=1,column=0,sticky='e')
        ttk.Label(root, textvariable=self.label_var, font=('Arial', 24)).grid(row=1,column=1,sticky='w')
        ttk.Button(root, text='Quit', command=self.close).grid(row=2,column=0,columnspan=2)
        # Start update thread
        threading.Thread(target=self.update_loop, daemon=True).start()

    def preprocess(self, frame):
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        h,w = gray.shape
        side = min(h,w)
        sx = (w-side)//2; sy = (h-side)//2
        crop = gray[sy:sy+side, sx:sx+side]
        img = cv2.resize(crop, (28,28))
        img = img.astype('float32')/255.0
        img = img.reshape(1,28,28,1)
        return img

    def update_loop(self):
        while self._running:
            ret, frame = self.cap.read()
            if not ret:
                continue
            img = frame.copy()
            # Display the video frame in the UI
            img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
            im_pil = Image.fromarray(img_rgb)
            imgtk = ImageTk.PhotoImage(image=im_pil)
            self.video_label.imgtk = imgtk
            self.video_label.configure(image=imgtk)
            # Predict once every 0.8s
            time.sleep(0.8)
            try:
                x = self.preprocess(frame)
                pred = self.model.predict(x)
                label = int(pred.argmax(axis=1)[0])
                label_text = LABEL_MAP.get(label, str(label))
                self.label_var.set(label_text)
                # Speak
                self.engine.say(label_text)
                self.engine.runAndWait()
            except Exception as e:
                logger.warning(f"Prediction error: {e}")
        logger.info('Update loop ended.')

    def close(self):
        self._running = False
        time.sleep(0.5)
        self.cap.release()
        self.root.quit()

if __name__ == '__main__':
    root = tk.Tk()
    app = App(root)
    root.protocol('WM_DELETE_WINDOW', app.close)
    root.mainloop()
