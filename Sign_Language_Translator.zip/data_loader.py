"""data_loader.py
- Downloads/loads Kaggle Sign Language MNIST dataset (if not present)
- Prepares train/test arrays and saves as numpy files for fast reuse
"""
import os
import numpy as np
import pandas as pd
from utils import logger, ensure_dir

DATA_DIR = os.path.join(os.getcwd(), "data")
ensure_dir(DATA_DIR)

def load_sign_mnist_from_csv(dataset_dir=None):
    """Load sign_mnist_train.csv and sign_mnist_test.csv if present in dataset_dir or ./data"""
    if dataset_dir is None:
        dataset_dir = DATA_DIR
    train_csv = os.path.join(dataset_dir, "sign_mnist_train.csv")
    test_csv = os.path.join(dataset_dir, "sign_mnist_test.csv")
    if not (os.path.exists(train_csv) and os.path.exists(test_csv)):
        logger.info("CSV files not found. Please download 'sign_mnist_train.csv' and 'sign_mnist_test.csv' into the data/ folder (see README)." )
        raise FileNotFoundError("Dataset CSV files not found. See README.")
    train_df = pd.read_csv(train_csv)
    test_df = pd.read_csv(test_csv)
    return train_df, test_df

def prepare_data(selected_labels=None):
    """Prepare numpy arrays (images normalized, shaped) for the chosen labels."""
    train_df, test_df = load_sign_mnist_from_csv()
    if selected_labels is None:
        # default: letters A-F (0-5 in many versions)
        selected_labels = [0,1,2,3,4,5]
    train_df = train_df[train_df['label'].isin(selected_labels)]
    test_df = test_df[test_df['label'].isin(selected_labels)]
    X_train = train_df.drop('label', axis=1).values.reshape(-1,28,28,1).astype('float32')/255.0
    y_train = train_df['label'].values.astype('int32')
    X_test = test_df.drop('label', axis=1).values.reshape(-1,28,28,1).astype('float32')/255.0
    y_test = test_df['label'].values.astype('int32')
    # Save for quick reuse
    np.save(os.path.join(DATA_DIR, 'X_train.npy'), X_train)
    np.save(os.path.join(DATA_DIR, 'y_train.npy'), y_train)
    np.save(os.path.join(DATA_DIR, 'X_test.npy'), X_test)
    np.save(os.path.join(DATA_DIR, 'y_test.npy'), y_test)
    logger.info(f"Saved prepared arrays to {DATA_DIR}")
    return X_train, y_train, X_test, y_test

if __name__ == '__main__':
    prepare_data()
