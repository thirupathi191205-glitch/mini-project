"""camera_capture.py
Capture a frame from webcam, preprocess (crop + grayscale + resize), and predict using model.
This is Colab-friendly only if using a local runtime or connecting to webcam; otherwise run locally.
"""
import cv2
import numpy as np
from predict import predict_image, load_image
from tensorflow import keras
from utils import logger
import tempfile, os

def capture_and_predict(save_tmp=False):
    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        logger.error('Cannot open webcam (0).')
        return None
    ret, frame = cap.read()
    cap.release()
    if not ret:
        logger.error('Failed to capture frame.')
        return None
    # Convert to grayscale, center crop, resize to 28x28
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    h, w = gray.shape
    side = min(h,w)
    startx = (w-side)//2
    starty = (h-side)//2
    crop = gray[starty:starty+side, startx:startx+side]
    img = cv2.resize(crop, (28,28))
    img_path = None
    if save_tmp:
        fd, img_path = tempfile.mkstemp(suffix='.png')
        os.close(fd)
        cv2.imwrite(img_path, img)
    # Prepare for prediction
    img_arr = img.astype('float32')/255.0
    img_arr = img_arr.reshape(1,28,28,1)
    # Load model and predict
    from tensorflow.keras.models import load_model
    model = load_model(os.path.join(os.getcwd(),'models','gesture_model.keras'))
    pred = model.predict(img_arr)
    label = int(pred.argmax(axis=1)[0])
    from utils import LABEL_MAP
    result = LABEL_MAP.get(label, str(label))
    logger.info(f"Predicted: {result}")
    if img_path:
        logger.info(f"Saved captured frame to {img_path}")
    return result

if __name__ == '__main__':
    print(capture_and_predict(save_tmp=True))
