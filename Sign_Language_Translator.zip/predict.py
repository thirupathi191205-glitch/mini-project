"""predict.py
Load saved Keras model and predict on a single (28x28) image or file.
Usage: python predict.py --image path_to_image.png
"""
import argparse
import numpy as np
import cv2
import os
from tensorflow import keras
from utils import LABEL_MAP, logger

MODEL_PATH = os.path.join(os.getcwd(), 'models', 'gesture_model.keras')

def load_image(path):
    img = cv2.imread(path, cv2.IMREAD_GRAYSCALE)
    img = cv2.resize(img, (28,28))
    img = img.astype('float32')/255.0
    img = img.reshape(1,28,28,1)
    return img

def predict_image(img):
    model = keras.models.load_model(MODEL_PATH)
    pred = model.predict(img)
    label = int(pred.argmax(axis=1)[0])
    return LABEL_MAP.get(label, str(label))

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--image', type=str, required=True, help='Path to image file (grayscale or color)')
    args = parser.parse_args()
    img = load_image(args.image)
    res = predict_image(img)
    print('Predicted:', res)
