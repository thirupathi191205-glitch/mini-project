"""train_model.py
Train a simple CNN on the Sign Language MNIST subset and save the model.
"""
import os
from utils import logger, ensure_dir, LABEL_MAP
from data_loader import prepare_data, DATA_DIR
import tensorflow as tf
from tensorflow.keras import layers, models

MODEL_DIR = os.path.join(os.getcwd(), 'models')
ensure_dir(MODEL_DIR)

def build_model(input_shape=(28,28,1), num_classes=6):
    model = models.Sequential([
        layers.Input(shape=input_shape),
        layers.Conv2D(32, (3,3), activation='relu'),
        layers.MaxPooling2D((2,2)),
        layers.Conv2D(64, (3,3), activation='relu'),
        layers.MaxPooling2D((2,2)),
        layers.Flatten(),
        layers.Dense(128, activation='relu'),
        layers.Dropout(0.3),
        layers.Dense(num_classes, activation='softmax')
    ])
    model.compile(optimizer='adam', loss='sparse_categorical_crossentropy', metrics=['accuracy'])
    return model

def train(epochs=10, batch_size=64):
    X_train, y_train, X_test, y_test = prepare_data()
    model = build_model(input_shape=X_train.shape[1:], num_classes=len(set(y_train)))
    model.summary()
    model.fit(X_train, y_train, validation_data=(X_test,y_test), epochs=epochs, batch_size=batch_size)
    model_path = os.path.join(MODEL_DIR, 'gesture_model.keras')
    model.save(model_path)
    logger.info(f"Model saved to {model_path}")
    return model_path

if __name__ == '__main__':
    train(epochs=5)
