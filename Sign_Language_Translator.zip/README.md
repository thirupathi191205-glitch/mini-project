
# Sign Language Translator — Complete Source Code (Executable)
This package contains a runnable Sign Language Translator using Deep Learning.
It is organized into modular Python scripts so you can run or modify parts individually.

**Contents**
- data_loader.py        : Download / load Sign Language MNIST dataset and prepare data
- train_model.py       : Train a CNN model and save it (Keras .keras)
- predict.py           : Load saved model and predict on an image
- camera_capture.py    : Real-time capture (OpenCV + Mediapipe preprocessing) and single-frame prediction
- gui.py               : Tkinter GUI to run camera, show prediction and speak using gTTS / pyttsx3
- utils.py             : Helper utilities (logging, label map)
- requirements.txt     : Python package requirements
- run_all_colab.ipynb  : (instructions inside README for Colab usage)
- sign_language_report.docx : Full report and source code (also included separately)

**How to run (basic)**:
1. Install requirements: `pip install -r requirements.txt`
2. Use `python train_model.py` to train (or download pre-trained model if available).
3. Use `python gui.py` to run the GUI for real-time predictions.
